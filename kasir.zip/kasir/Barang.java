/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javakasir;

/**
 *
 * @author ACER
 */
public class Barang {
    int id;
String namaBarang;
int stockBarang, hargaBarang, terjual;

    public Barang(int id, String namaBarang, int stockBarang, int hargaBarang, int terjual) {
        this.id = id;
        this.namaBarang = namaBarang;
        this.stockBarang = stockBarang;
        this.hargaBarang = hargaBarang;
        this.terjual = terjual;
    }

}

    

